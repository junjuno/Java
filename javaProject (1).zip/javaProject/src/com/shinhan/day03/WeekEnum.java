package com.shinhan.day03;

//enum(enumeration)한정적인 값들을 묶음
public enum WeekEnum {
	MONDAY, TUESDAY,WEDNESDAY, 
	THURSDAY,FRIDAY,SATURDAY,
	SUNDAY
}
