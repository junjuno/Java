package com.shinhan.day03;

public enum LoginEnum {
	SUCCESS, FAIL
}
