package com.shinhan.day01;

//class = 변수들 + 함수들
public class Hello2 {
	//main은 프로그램의 시작점 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("1자바연습");
		 
		System.out.println("2자바연습");System.out.println("3자바연습"); 
		System.out.println("4자바연습"); 
		System.out.println("5자바연습"); 
		 
	}

}
