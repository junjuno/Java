package com.shinhan.day01;

class A{
	
}
class B{
	
}
public class Hello {

	public static void main(String[] args) {
		System.out.println("안녕하세요1");
		System.out.println("안녕하세요2");
		System.out.println("안녕하세요3");
		System.out.println("안녕하세요4");
		System.out.println("안녕하세요5");
		
		// 사람에게 프로그램 설명(주석)
		/*  
		 사람에게 프로그램 설명(주석) 
		 */

	}

}
