package com.shinhan.day04;

//같은패키지연습
public class MofierTestDay04 {
	public static void main(String[] args) {
		Phone p = new Phone();
		p.model = "켈럭시22";
		System.out.println(p);
		p.f1();p.f2(); p.f3();
	}
}
