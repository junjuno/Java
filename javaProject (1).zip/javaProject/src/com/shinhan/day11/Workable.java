package com.shinhan.day11;

@FunctionalInterface
public interface Workable {

	void work(String name, String job);
}
