package com.shinhan.day11;

public interface MyInterface {
	//추상메서드 정의
	void print();
}
