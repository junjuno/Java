package com.shinhan.day11;

public class MyClassImplement implements MyInterface{

	@Override
	public void print() {
		System.out.println("MyClassImplement에서 구현합니다....");
		
	}

}
