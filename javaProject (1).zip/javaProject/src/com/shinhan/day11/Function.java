package com.shinhan.day11;

public interface Function {

	double apply(double x, double y);
}
