package com.shinhan.day05;


abstract class  Parent3{
	Parent3(int a){
		
	}
	void f(){
		
	}
}
class Child3 extends Parent3{
	Child3(){
		super(1);
	}
}

public class Test {
	 
	
	public static void main(String[] args) {
		Test a = new Test();

	}

}
