package com.shinhan.day05;

public interface WIFI {
	//상수
	//추상메서드
	void wifiTurnOn();
	//default메서드
	//static메서드
}
