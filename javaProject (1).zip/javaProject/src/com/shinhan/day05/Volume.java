package com.shinhan.day05;

public interface Volume{
	public abstract void volumeUp(int volLevel);
	void volumeDown(int volLevel);
}

/*
public abstract class Volume {
	abstract void volumeUp(int volLevel);
	abstract void volumeDown(int volLevel);
}
*/