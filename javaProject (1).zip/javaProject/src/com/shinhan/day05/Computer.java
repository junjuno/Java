package com.shinhan.day05;

public class Computer extends Machine{

	public Computer(int a) {
		super(a);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

	
}
