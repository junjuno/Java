package com.shinhan.day05;

public interface AllInterface extends RemoteControl, WIFI{
    void print();
}
