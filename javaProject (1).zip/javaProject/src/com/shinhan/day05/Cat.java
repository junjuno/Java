package com.shinhan.day05;

public non-sealed class Cat extends Animal{
    int b=20;
    void method2() {
    	System.out.println("**Cat자식에서 추가메서드method2");
    }
	 
}
