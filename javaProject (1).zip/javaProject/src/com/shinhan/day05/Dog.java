package com.shinhan.day05;

public non-sealed class Dog extends Animal {
	int c=30;
	void method3() {
    	System.out.println("**Dog자식에서 추가메서드method3");
    }
	 
}
