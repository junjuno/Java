package com.shinhan.day05.lab;

public interface Resizable {
	public abstract void resize(double s);
}
