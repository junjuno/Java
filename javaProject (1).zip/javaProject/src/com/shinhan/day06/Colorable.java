package com.shinhan.day06;

public interface Colorable {
	public abstract void setForeground(String color);
	void setBackground(String color);
}
