package com.shinhan.day06;

public interface Changeable extends Resizable, Colorable {
	void setFont(String font);
}
