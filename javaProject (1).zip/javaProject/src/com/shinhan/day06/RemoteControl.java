package com.shinhan.day06;

public interface RemoteControl {

	void turnOn();
	void turnOff();
	
}
