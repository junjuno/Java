package com.shinhan.day06;
public interface Resizable {
	//public abstract생략가능 
	public abstract void size(int width, int height) ;
}
