package com.shinhan.day06;


public class OKListener implements Button.ClickListener {

	@Override
	public void onClick() {
		System.out.println("OK Button클릭시 수행되는 로직입니다.");
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@");
	}

}
