package com.shinhan.day07;

//14버젼부터 
//record
//constructor, getter, toString, equals 메소드를 자동 생성
public record Person(String name, int age) {
	 
}
