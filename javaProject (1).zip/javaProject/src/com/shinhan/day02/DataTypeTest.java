package com.shinhan.day02;

public class DataTypeTest{
	public static void main(String s[]){
 
	int tom = -1;
	char marry = '9';
	boolean john = false ;  //주의 
	String sarah = "Sarah Jang" ;
	System.out.println( "our friends..\n" 
		+ tom + ", " + marry + ", " + john + " and " + sarah);
	 } //main end
} //class end

//[클래스 실행결과]
//our friends..
//-1, 9, false and Sarah Jang
