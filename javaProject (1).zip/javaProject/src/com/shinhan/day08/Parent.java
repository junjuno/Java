package com.shinhan.day08;

public class Parent {

}
