package com.shinhan.day08;

public class Person {

}

class Worker extends Person{
	
}

class Student extends Person{
	
}
class HighStudent extends Student{
	
}
class MiddleStudent extends Student{
	
}