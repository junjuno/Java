/**
 * @author PC
 *
 */
module javaProject {
	requires java.sql;
	requires lombok;
	requires org.json; 
	exports com.shinhan.day01;
	exports com.shinhan.day02;
	exports com.shinhan.day03;
	exports com.shinhan.day04;
	exports com.shinhan.day05;
	exports com.shinhan.day06;
 
}